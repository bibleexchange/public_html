/* JavaScript for the Example skin */
